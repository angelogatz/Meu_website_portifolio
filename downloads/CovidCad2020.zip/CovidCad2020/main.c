/*inicio da criacao do sistema pim 4*/
#include<stdio.h>
#include<string.h>
#define SIZE 200
#include<conio.h>
#include<stdlib.h>

/*inicio func�o cadastro*/
char pacienterisco[SIZE][50];
char idadepaciente[SIZE][50];
char nome[SIZE][50];
char email[SIZE][50];
char cpf[SIZE][50];
char telefone[SIZE][50];
char nascimento[SIZE][50];
char diadiagnostico[SIZE][50];
char comorbidades[SIZE][50];
char rua[SIZE][50];
char cep[SIZE][50];
char numerodacasa[SIZE][50];
char cidade[SIZE][50];
char estado[SIZE][50];
char bairro[SIZE][50];
int idade;
int op;

typedef struct{
     char login[30];
     char senha[30];
} usuario; usuario u[1];



void text();
void cadastro();
void pesquisa();
void lista();
int main(void){

    char login[30];
    char senha[30];

    strcpy(u[0].login, "joao");
    strcpy(u[0].senha, "123");

    printf("\t\t\t\t\t\t-COVID-CAD-");
    printf("\n\t\t\t\t\t\t --Pim-VI--");
    printf("\n\t\t\t\t\t\t\t\t\t\t Nasser Saad El Sawy");
    printf("\n\t\t\t\t\t\t\t\t\t\t Angelo Augusto Alves Gatz");
    printf("\n\n\t\t\t\tUsuario: ");
    scanf("%s", login);
    printf("\n\n\t\t\t\tSenha: ");
    scanf("%s", senha);

    if ((strcmp(login,u[0].login)==0) || (strcmp(senha,u[0].senha)==0)){
        menu();
        }else{
            printf("Usuario ou senha invalidos\n\n");
        }
    }
void menu(){
    do{
        system("color B0");
        system("cls");
        printf("\n\n\n\t\t\t\t\t\t---------- Menu ----------\n\n\n");
        printf("\n\t\t\t\t\t\t     1 - Cadastrar\n\n\t\t\t\t\t\t     2 - Listar todos\n\n\t\t\t\t\t\t     3 - Pesquisar\n\n\t\t\t\t\t\t     4 - Sair ");
        scanf("%d", &op);
        switch(op){
         case 1:
             cadastro();
            break;
         case 2:
            lista();
            break;
         case 3:
            pesquisa();
            break;
         case 4:
            system("exit");
            break;
         default:
            printf("Opcao Invalida");
            getchar();
            getchar();
            break;

        }
    }while(op!=4);

}
void lista(){
    system("color E0");
    system("cls");
    int i;
    for(i=0;i<SIZE;i++){
        if(cpf[i]!=0){
            printf("\n\n\t\t\t\t---------- Registro de todos os cadastros ----------\t\t\t\t\t\t\n\n\n");

            printf("\n\t\t\tNome: %s", nome[i]);
            printf("\n\t\t\tEmail: %s", email[i]);
            printf("\n\t\t\tCPF: %s", cpf[i]);
            printf("\n\t\t\tTelefone: %s", telefone[i]);
            printf("\n\t\t\tIdade: %s", idadepaciente[i]);
            printf("\n\t\t\tData de nascimento: %s", nascimento[i]);
            printf("\n\t\t\tRua: %s", rua[i]);
            printf("\n\t\t\tNumero da residencia: %s", numerodacasa[i]);
            printf("\n\t\t\tBairro da residencia: %s", bairro[i]);
            printf("\n\t\t\tCidade: %s", cidade[i]);
            printf("\n\t\t\tEstado: %s", estado[i]);
            printf("\n\t\t\tCEP: %s", cep[i]);
            printf("\n\t\t\tData da consulta: %s", diadiagnostico[i]);
            printf("\n\t\t\tComorbidades: %s", comorbidades[i]);

            printf("\n\n\n------------------------------------------------------------------------------------------------------------------------");

            getchar();
            getchar();
        }
        else{
            system("cls");
            printf("Nenhum Cadastro encontrado");
            break;
        }

    }
    getchar();
    getchar();
}
void cadastro(){
    system("color F2");
    system("cls");
    printf("\n\n\n\t\t\t\t\t     BEM VINDO ao Sistema de Cadastro \t\t\t\t\t\t\n");
    printf("\n\t\t\t\t\t\tPreencha os campos a baixo \t\t\t\t\t\t\n\n\n");
   static int linha;
   do{
      printf("\n\t\t\tNome do paciente: ");
      scanf(" %[^\n]s", &nome[linha]);
      printf("\n\t\t\tEmail do paciente: ");
      scanf(" %[^\n]s", &email[linha]);
      printf("\n\t\t\tDigite o cpf: ");
      scanf(" %[^\n]s", &cpf[linha]);
      printf("\n\t\t\tDigite a idade do paciente: ");
      scanf(" %[^\n]s", &idadepaciente[linha]);
      printf("\n\t\t\tDigite a data de nascimeto: ");
      scanf(" %[^\n]s", &nascimento);
      printf("\n\t\t\tDigite o numero de telefone: ");
      scanf(" %[^\n]s", &telefone[linha]);
      printf("\n\t\t\tDigite o dia do diagnostico: ");
      scanf(" %[^\n]s", &diadiagnostico[linha]);
      printf("\n\t\t\tDigite a rua ou avenida da residencia: ");
      scanf(" %[^\n]s", &rua[linha]);
      printf("\n\t\t\tDigite o numero da residencia: ");
      scanf(" %[^\n]s", &numerodacasa[linha]);
      printf("\n\t\t\tDigite o bairro da residencia: ");
      scanf(" %[^\n]s", &bairro[linha]);
      printf("\n\t\t\tDigite a Cidade: ");
      scanf(" %[^\n]s", &cidade[linha]);
      printf("\n\t\t\tDigite o Estado: ");
      scanf(" %[^\n]s", &estado[linha]);
      printf("\n\t\t\tDigite o CEP: ");
      scanf(" %[^\n]s", &cep[linha]);
      printf("\n\t\t\tO paciente possui alguma comorbidade?: ");
      scanf(" %[^\n]s", &comorbidades[linha]);
      printf("\n\t\t\tDigite 1 para continuar ou outro valor para sair: ");
      scanf("%d", &op);
        system("cls");
    if (idadepaciente>=60){

       FILE *pacienterisco;
       pacienterisco = fopen("Pacientes_de_Risco", "w");

       if(pacienterisco == NULL)
       {
           printf("Erro na abertura do arquivo!");
           return 1;
       }
       else{
        fprintf(pacienterisco, "\nNome: %s", &nome);
        fprintf(pacienterisco, "\nData de nascimento: %s", &nascimento);
        fprintf(pacienterisco, "\nCPF: %s", &cpf);
        fprintf(pacienterisco, "\nIdade: %s", &idadepaciente);
        fprintf(pacienterisco, "\nDia da consulta: %s", &diadiagnostico);
        fprintf(pacienterisco, "\nComorbidades: %s", &comorbidades);

        fclose(pacienterisco);
        system("cls");
        printf("\n\t\t\tDados gravados com sucesso!");
        }
        getch();
        return (0);
        return (0);
     }else{
        printf("\n\t\t\tEste nao e um paciente de risco");
            getchar();
            getchar();
     }
       system("cls");
     if (comorbidades=="diabetes"){

       FILE *pacienterisco;
       pacienterisco = fopen("Pacientes_de_Risco", "w");

       if(pacienterisco == NULL)
       {
           printf("Erro na abertura do arquivo!");
           return 1;
       }
       else{
        fprintf(pacienterisco, "\nNome: %s", &nome);
        fprintf(pacienterisco, "\nData de nascimento: %s", &nascimento);
        fprintf(pacienterisco, "\nCPF: %s", &cpf);
        fprintf(pacienterisco, "\nIdade: %s", &idadepaciente);
        fprintf(pacienterisco, "\nDia da consulta: %s", &diadiagnostico);
        fprintf(pacienterisco, "\nComorbidades: %s", &comorbidades);

        fclose(pacienterisco);
        system("cls");
        printf("\n\t\t\tDados gravados com sucesso!");
        }
        getch();
        return (0);
        return (0);
     }else{
        printf("\n\t\t\tEste nao e um paciente de risco");
            getchar();
            getchar();
     }
     system("cls");
     if (comorbidades=="hipertensao"){

       FILE *pacienterisco;
       pacienterisco = fopen("Pacientes_de_Risco", "w");

       if(pacienterisco == NULL)
       {
           printf("Erro na abertura do arquivo!");
           return 1;
       }
       else{
        fprintf(pacienterisco, "\nNome: %s", &nome);
        fprintf(pacienterisco, "\nData de nascimento: %s", &nascimento);
        fprintf(pacienterisco, "\nCPF: %s", &cpf);
        fprintf(pacienterisco, "\nIdade: %s", &idadepaciente);
        fprintf(pacienterisco, "\nDia da consulta: %s", &diadiagnostico);
        fprintf(pacienterisco, "\nComorbidades: %s", &comorbidades);

        fclose(pacienterisco);
        system("cls");
        printf("\n\t\t\tDados gravados com sucesso!");
        }
        getch();
        return (0);
        return (0);
     }else{
        printf("\n\t\t\tEste nao e um paciente de risco");
            getchar();
            getchar();
     }
     system("cls");
     if (comorbidades=="asma"){

       FILE *pacienterisco;
       pacienterisco = fopen("Pacientes_de_Risco", "w");

       if(pacienterisco == NULL)
       {
           printf("Erro na abertura do arquivo!");
           return 1;
       }
       else{
        fprintf(pacienterisco, "\nNome: %s", &nome);
        fprintf(pacienterisco, "\nData de nascimento: %s", &nascimento);
        fprintf(pacienterisco, "\nCPF: %s", &cpf);
        fprintf(pacienterisco, "\nIdade: %s", &idadepaciente);
        fprintf(pacienterisco, "\nDia da consulta: %s", &diadiagnostico);
        fprintf(pacienterisco, "\nComorbidades: %s", &comorbidades);

        fclose(pacienterisco);
        system("cls");
        printf("\n\t\t\tDados gravados com sucesso!");
        }
        getch();
        return (0);
        return (0);
     }else{
        printf("\n\t\t\tEste nao e um paciente de risco");
            getchar();
            getchar();
     }
     system("cls");
     if (comorbidades=="bronquite"){

       FILE *pacienterisco;
       pacienterisco = fopen("Pacientes_de_Risco", "w");

       if(pacienterisco == NULL)
       {
           printf("Erro na abertura do arquivo!");
           return 1;
       }
       else{
        fprintf(pacienterisco, "\nNome: %s", &nome);
        fprintf(pacienterisco, "\nData de nascimento: %s", &nascimento);
        fprintf(pacienterisco, "\nCPF: %s", &cpf);
        fprintf(pacienterisco, "\nIdade: %s", &idadepaciente);
        fprintf(pacienterisco, "\nDia da consulta: %s", &diadiagnostico);
        fprintf(pacienterisco, "\nComorbidades: %s", &comorbidades);

        fclose(pacienterisco);
        system("cls");
        printf("\n\t\t\tDados gravados com sucesso!");
        }
        getch();
        return (0);
        return (0);
     }else{
        printf("\n\t\t\tEste nao e um paciente de risco");
            getchar();
            getchar();
     }
     system("cls");
        linha++;
      }while(op==1);


     }

/*fim da fun��o cadastro e inicio da fun��o pesquisa*/
   void pesquisa(){
       system("color F0");
       system("cls");
    char cpfPesquisa[50];
    char emailPesquisa[50];
    int i;
    do{
      printf("\n\n\t\t\t\t\t\t---------- BEM VINDO ----------");
      printf("\n\t\t\t\t\t                       A           ");
      printf("\n\t\t\t\t\t   --------- Pesquisa de Cadastros! ----------\n\n\n");
      printf("\n\t\t\tDigite 1 para pesquisar por CPF ou 2 para pesquisar por E-Mail: ");
      scanf("%d", &op);
      switch(op){
         case 1:
             printf("\nDigite o CPF: ");
             scanf(" %[^\n]s", &cpfPesquisa);
             for(i=0;i<SIZE;i++){
                if(strcmp(cpf[i], cpfPesquisa)==0){
                    printf("\nNome: %s\nEmail: %s\nCPF: %s\nTelefone: %s\nIdade: %s\nData de nascimento: %s\nRua: %s\nNumero da residencia: %s\nCidade: %s\nEstado: %s\nBairro: %s\nCEP: %s\nDia do Diagnostico: %s\nComorbidade: %s\n", nome[i], email[i], cpf[i], telefone[i], idadepaciente[i], nascimento[i], rua[i], numerodacasa[i], cidade[i], estado[i], bairro[i], cep[i], diadiagnostico[i], comorbidades[i]);
                }
             }
            break;
         case 2:
             printf("\nDigite o E-Mail: ");
             scanf("%s", emailPesquisa);
             for(i=0;i<SIZE;i++){
                if(strcmp(email[i], emailPesquisa)==0){
                    printf("\nNome: %s\nEmail: %s\nCPF: %s\nTelefone: %s\nIdade: %s\nData de nascimento: %s\nRua: %s\nNumero da residencia: %s\nCidade: %s\nEstado: %s\nBairro: %s\nCEP: %s\nDia do Diagnostico: %s\nComorbidade: %s\n", nome[i], email[i], cpf[i], telefone[i], idadepaciente[i], nascimento[i], rua[i], numerodacasa[i], cidade[i], estado[i], bairro[i], cep[i], diadiagnostico[i], comorbidades[i]);
                }
             }
            break;
        default:
             printf("\nOpcao invalida");
            break;
         }
         printf("\nDigite 1 para continuar pesquisando: ");
         scanf("%d", &op);
      }while(op==1);
   }













